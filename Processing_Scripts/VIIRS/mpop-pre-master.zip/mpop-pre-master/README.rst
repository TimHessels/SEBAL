This is the Meteorological Post-Processing Package (MPoP). 

A recent build of the documentation is available at
http://mpop.readthedocs.org/.

