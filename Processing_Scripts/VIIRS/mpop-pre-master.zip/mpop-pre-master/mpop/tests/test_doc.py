#!/usr/bin/env python

import doctest

#doctest.testfile("../doc/source/quickstart.rst")
